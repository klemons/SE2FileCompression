/**
 * Kyle Lemons
 * 11/15/19
 * CS 375 - SE 2
 * UntarsTest
 *
 * Tests Untars.java
 */

import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class UntarsTest {

    // This first test checks if the known file exists with a previously known name
    @Test
    public void Test1() throws IOException {
        Untars.main(new String[] {"src/files/archive.tar"});
        File testFile = new File("src/files/blee1.txt");
        assertTrue(testFile.exists());
    }

    // This second test checks the contents of the Untared file
    @Test
    public void Test2() throws IOException {
        BinaryIn in = null;
        String knownContent = "Abracadabra";
        String unknownContent ="";
        String filenameKnown = "src/files/blee1.txt";
        Untars.main(new String[] {"src/files/archive.tar"});
        in = new BinaryIn(filenameKnown);
        while (!in.isEmpty()) {
            unknownContent += in.readChar();
        }
        assertEquals(knownContent, unknownContent);
    }

    // These next two tests are to confirm it will work besides just one specific tar file
    @Test
    public void Test3() throws IOException {
        Untars.main(new String[] {"src/files/secondArchive.tar"});
        File testFile = new File("src/files/emacs.txt");
        assertTrue(testFile.exists());
    }

    @Test
    public void Test4() throws IOException {
        BinaryIn in = null;
        String knownContent = "The Mandalorian is pretty cool";
        String unknownContent ="";
        String filenameKnown = "src/files/emacs.txt";
        Untars.main(new String[] {"src/files/secondArchive.tar"});
        in = new BinaryIn(filenameKnown);
        while (!in.isEmpty()) {
            unknownContent += in.readChar();
        }
        assertEquals(knownContent, unknownContent);
    }
}
